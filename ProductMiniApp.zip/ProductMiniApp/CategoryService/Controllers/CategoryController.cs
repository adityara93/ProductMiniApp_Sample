﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using CategoryService.Models;
using CategoryService.Services;
using System.Data.SqlClient;

namespace CategoryService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public CategoryController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public ResponseCategory Get()
        {
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("FolkaShopDB").ToString());
            ResponseCategory responseCategory = new ResponseCategory();
            ICategory iCategories = new ICategory();
            responseCategory = iCategories.GetCategory(connection);

            return responseCategory;
        }
    }
}
