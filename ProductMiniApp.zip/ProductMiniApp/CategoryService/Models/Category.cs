﻿using System.ComponentModel.DataAnnotations;
using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace CategoryService.Models
{
    [Table("Product")]
    public class Category
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
    }
    public class ResponseCategory
    {
        public int MsgCode { get; set; }
        public string MsgInfo { get; set; }
        public List<Category> Categories { get; set; }
    }
}
