﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ProductService.Models;
using ProductService.Services;
using System.Data.SqlClient;

namespace ProductService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public ProductController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public ResponseProduct Get()
        {
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("FolkaShopDB").ToString());
            ResponseProduct responseProduct = new ResponseProduct();
            IProduct iProduct = new IProduct();
            responseProduct = iProduct.GetProduct(connection);

            return responseProduct;
        }
    }
}
